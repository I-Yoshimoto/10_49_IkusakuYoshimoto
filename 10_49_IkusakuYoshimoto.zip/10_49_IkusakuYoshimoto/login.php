<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>ログイン</title>
  <meta name="viewport" content="width=device-width">
  <!-- <link rel="stylesheet" href="css/main.css" />
  <link href="css/bootstrap.min.css" rel="stylesheet"> -->
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <div class="login_header_container">
        <h1 class="login_heading">Your Exhibition</h1>

        <!-- login_act.phpに「post」でデータを送る -->
        <div class="login_form_container">
            <form name="form1" action="login_act.php" method="post" class="login_form">
                ID: <input type="text" name="lid" class="id" />
                PW: <input type="password" name="lpw" class="password" />
                <input type="submit" value="ログイン" />
            </form>
        </div>
    </div>
</header>

    <p class="login_subheading">ここは、誰もが個展を開ける場所。<br>
    あなたの作品を待っています。</p>


    <!-- <a class="top_page" href="index.php">トップページへ</a> -->


  </div>
 
    <p class="in_progress">開催中</p>

    <!-- ここからexhibition_list -->
    <div class="exhibition_list">
        <div class="list_container">
            <img src="img/birth.jpg" alt="">
            <div class="overview_container">
                <p class="exhibition_title">一日一葉　「双葉の心」展</p>
                <p class="term">会期: 2020年7月1日(水) 〜 7月12日(日)</p>
                <p class="explanation">双葉アーティスト◯◯よる・・・</p>
                <a href="sample_pages/introduction.html">観賞する</a>
                
            </div>
           
        </div>
        <div class="list_container">
            <img src="img/kitahotakadake.jpg " alt="">
            <div class="overview_container">
                <p class="exhibition_title">山好き男　「槍・穂高　縦走」展</p>
                <p class="term">会期: 2020年7月15日(水) 〜 7月26日(日)</p>
                <p class="explanation">北アルプスを代表する縦走路である・・・</p>
            </div>
        </div>
        <div class="list_container">
            <img src="img/sample-img_green.jpg" alt="">
            <div class="overview_container">
                <p class="exhibition_title">アーティスト名　「緑の香り」展</p>
                <p class="term">会期: 2020年7月29日(水) 〜 8月9日(日)</p>
                <p class="explanation">この展覧会は・・・</p>
            </div>
        </div>
        <div class="list_container">
            <img src="img/sample-img_blue.jpg" alt="">
            <div class="overview_container">
                <p class="exhibition_title">アーティスト名　「蒼き海」展</p>
                <p class="term">会期: 2020年7月29日(水) 〜 8月9日(日)</p>
                <p class="explanation">この展覧会は・・・</p>
            </div>
        </div>
    </div>
    <!-- ここまでexhibition_list -->

    <p class="upcoming">開催予定</p>


















</body>
</html>