<?php
//1. POSTデータ取得
$term          = $_POST["term"];
$artist_name = $_POST["artist_name"];
$exhibition_title       = $_POST["exhibition_title"];
$explanation   = $_POST["explanation"];
$website_url  = $_POST["image"];
$id            = $_POST["id"];


//2. DBに接続する
require "funcs.php";//funcs.phpに書いた関数を呼び出す
$pdo = db_conn();


//３．データ登録SQL作成（3.UPDATE gs_bm_table SET ....; で更新）
$stmt = $pdo->prepare("UPDATE exhibition_entry_table SET term=:a1, artist_name=:a2, exhibition_title=:a3, explanation=:a4, website_url=:a5, image=:a6 WHERE id=:id");
$stmt->bindValue(':a1', $term, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
$stmt->bindValue(':a2', $artist_name, PDO::PARAM_STR);  
$stmt->bindValue(':a3', $exhibition_title, PDO::PARAM_STR);  
$stmt->bindValue(':a4', $explanation, PDO::PARAM_STR);  
$stmt->bindValue(':a5', $website_url, PDO::PARAM_STR);  
$stmt->bindValue(':a6', $image, PDO::PARAM_STR);  
$stmt->bindValue(':id', $id, PDO::PARAM_STR);
$status = $stmt->execute();

//４．データ登録処理後
if($status==false){
  sql_error($stmt);
}else{
  redirect("select.php");
}
?>
