<?php
//1. POSTデータ取得（index.phpのフォームからデータを受け取る）
$term = $_POST["term"];
$artist_name = $_POST["artist_name"];
$exhibition_title = $_POST["exhibition_title"];
$explanation = $_POST["explanation"];
$website_url = $_POST["website_url"];

//[FileUploadCheck--START--]
if (isset($_FILES["upfile"] ) && $_FILES["upfile"]["error"] ==0 ) {
    //ファイル名を取得
    $file_name = $_FILES["upfile"]["name"];
    //一時ファイル保存場所
    $tmp_path  = $_FILES["upfile"]["tmp_name"];
    //拡張子取得
    $extension = pathinfo($file_name, PATHINFO_EXTENSION);
    //新しいファイル名作成
    $file_name = date("YmdHis").md5(session_id()) . "." . $extension;

    // FileUpload [--Start--]
    $img="";
    $file_dir_path = "upload/".$file_name;
    if ( is_uploaded_file( $tmp_path ) ) {
        if ( move_uploaded_file( $tmp_path, $file_dir_path ) ) {
            chmod( $file_dir_path, 0644 );
            $img = '<img src="'.$file_dir_path.'">';

            //2. DB接続します
            require "funcs.php"; //funcs.phpに書いた関数を呼び出す
            $pdo = db_conn();

            //３．データ登録SQL作成
            $stmt = $pdo->prepare("INSERT INTO exhibition_entry_table(id,term,artist_name,exhibition_title,explanation,website_url,image,indate)
            VALUES(NULL,:term,:artist_name,:exhibition_title,:explanation,:website_url,:upfile,:sysdate());
            $stmt->bindValue(':term', $term, PDO::PARAM_STR);  //Integer（数値の場合 PDO::PARAM_INT)
            $stmt->bindValue(':artist_name', $artist_name, PDO::PARAM_STR); 
            $stmt->bindValue(':exhibition_title', $exhibition_title, PDO::PARAM_STR); 
            $stmt->bindValue(':explanation', $explanation, PDO::PARAM_STR); 
            $stmt->bindValue(':website_url', $website_url, PDO::PARAM_STR); 

            $stmt->bindValue(':image', $file_name, PDO::PARAM_STR); 
            $status = $stmt->execute(); //実行


            //４．データ登録処理後
            if($status==false){
              sql_error($stmt);
            }else{
              redirect("index.php");
            }

        } else {
            // echo "Error:アップロードできませんでした。";
        }
      }

 }else{
     $img = "画像が送信されていません";
 }
 //[FileUploadCheck--END--] 

?>

