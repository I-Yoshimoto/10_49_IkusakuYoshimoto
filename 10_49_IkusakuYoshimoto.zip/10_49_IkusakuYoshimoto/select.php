<?php
//セッションスタート
session_start();

//funcs.phpからログインチェックの関数を呼び出して実行する
require "funcs.php"; 
loginCheck();

//1.DB接続する
$pdo = db_conn();

//２．データ登録SQL作成
$stmt = $pdo->prepare("SELECT * FROM exhibition_entry_table");
$status = $stmt->execute();

//３．データ表示
$view="";
if($status==false) {
  sql_error($stmt);
}else{
  while( $result = $stmt->fetch(PDO::FETCH_ASSOC)){ 

//以下をtabelタグの中に入れる
$view .= "<tr>";

  $view .= "<td>";
      $view .= '<a href="detail.php?id='.$result["id"].'">';
        $view .= $result['term'];
      $view .= '</a>';
  $view .= "</td>";
  $view .= "<td>";
      $view .= '<a href="detail.php?id='.$result["id"].'">';
        $view .= $result['artist_name'];
      $view .= '</a>';
  $view .= "</td>";
  $view .= "<td>";
      $view .= '<a href="detail.php?id='.$result["id"].'">';
        $view .= $result['exhibition_title'];
      $view .= '</a>';
  $view .= "</td>";
  $view .= "<td>";
      $view .= '<a href="detail.php?id='.$result["id"].'">';
        $view .= $result['explanation'];
      $view .= '</a>';
  $view .= "</td>";
  $view .= "<td>";  
      $view .= '<a href="'.$result["website_url"].'">';
        $view .= $result["website_url"];
      $view .= '</a>';
  $view .= "</td>";
  $view .= "<td>";  
      $view .= '<a href="'.$result["website_url"].'">';
        $view .= $result["upfile"];
      $view .= '</a>';
  $view .= "</td>";

  $view .= "<td>";
      $view .= '<a href="delete.php?id='.$result["id"].'">';
        $view .= "✖️ 削除";
      $view .= "</a>"; 
  $view .= "</td>";

$view .= "</tr>";   

  }
}
?>


<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exhibition List</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body id="main">


<div class="list_wrapper">

  <header>
      <div class="header_container">  
        <h1 class="list_heading">登録一覧</h1>
        <div>
            <a class="register_change_button" href="index.php">新規登録</a>
        </div>
      </div>
  </header>

  <!-- 登録一覧表 -->
  <table>
      <tr>
        <th class="term">会期</th>
        <th class="artist_name">アーティスト名</th>
        <th class="exhibition_title">展覧会タイトル</th>
        <th class="explanation">説明</th>
        <th class="url">HP/SNS</th>
        <th class="image">作品画像</th>
        <th class="delete_button">削除</th>
      </tr>
      <div><?=$view?></div>

  </table>

</div>


</body>
</html>