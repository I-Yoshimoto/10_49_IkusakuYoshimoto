<?php
session_start();

$id = $_GET["id"]; //?id~**を受け取る
require "funcs.php"; //funcs.phpの関数を呼び出す

loginCheck(); //ログインチェックの関数を実行する（ログイン認証する）

// DBに接続する
$pdo = db_conn();

//２．データ登録SQL作成
$stmt = $pdo->prepare("SELECT * FROM exhibition_entry_table WHERE id=:id");
$stmt->bindValue(":id",$id,PDO::PARAM_INT);
$status = $stmt->execute();

//３．データ表示
if($status==false) {
    sql_error($stmt);
}else{
    $row = $stmt->fetch();
}
?>



<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>展覧会　登録画面</title>
  <!-- <link href="css/bootstrap.min.css" rel="stylesheet">
  <style>div{padding: 10px;font-size:16px;}</style> -->
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>


<!-- Main[Start] -->
<form method="POST" action="update.php"> <!-- update.phpにデータを飛ばす -->
   
  <fieldset>

    <div class="index_heading">
        <legend>展覧会へのエントリー（更新画面）</legend>
        <div class="list_button_box">
            <a class="list_button" href="select.php">登録一覧</a>
        </div>
    </div>

    <div class="index_heading">
        <legend>展覧会へのエントリー</legend>
        <div class="list_button_box">
            <a class="list_button" href="select.php">登録画面</a>
        </div>
    </div>

    <div class="entry_form">    
    <p class="sub_heading">以下の項目を入力して登録</p>
        <label>会期：<input type="date" name="term" value="<?=$row['term']?>" class="entry_form"></label><br>
        <label>アーティスト名：<input type="text" name="artist_name" value="<?=$row['artist_name']?>" class="entry_form"></label><br>
        <label>展覧会のタイトル：<input type="text" name="exhibition_title" value="<?=$row['exhibition_title']?>" class="entry_form"></label><br>
        <label>説明文： <textarea name="explanation" rows="4" cols="40" class="entry_explanation"><?=$row['explanation']?></textarea></label><br>
        <label>HP／SNS：<input type="text" name="website_url" value="<?=$row['website_url']?>" class="entry_form"></label><br>
        <label>画像：<input type="file" name="image"  value="<?=$row['image']?>" class="entry_form"></label><br>
        <input type="submit" value="登録する" class="register">
        <input type="hidden" name="id" value="<?=$row['id']?>">

    </div>

  </fieldset>

</form>
<!-- Main[End] -->


</body>
</html>
