<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>登山記録</title>
  <!-- <link href="css/bootstrap.min.css" rel="stylesheet">
  <style>div{padding: 10px;font-size:16px;}</style> -->
  <link rel="stylesheet" href="css/reset.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>


<!-- Head[Start] -->
<header>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
    <!-- <div class="navbar-header"><a class="navbar-brand" href="select.php">データ一覧</a></div> -->
      <div class="page_change_container">
        <!-- <a class="login_page" href="login.php">ログイン</a> -->
        <a class="logout_button" href="logout.php">ログアウト</a>
      </div>
    </div>
  </nav>
</header>
<!-- Head[End] -->



<!-- Main[Start] -->
<!-- <form method="POST" action="insert.php" > insert.phpにデータを飛ばす -->
<form method="post" action="insert.php" enctype="multipart/form-data">

  <fieldset>

    <div class="index_heading">
        <legend>展覧会へのエントリー</legend>
        <div class="list_button_box">
            <a class="list_button" href="select.php">登録画面</a>
        </div>
    </div>

    <div class="entry_form">    
    <p class="sub_heading">以下の項目を入力して登録</p>
        <label>会期：<input type="date" name="term" class="entry_form"></label><br>
        <label>アーティスト名：<input type="text" name="artist_name" class="entry_form"></label><br>
        <label>展覧会のタイトル：<input type="text" name="exhibition_title" class="entry_form"></label><br>
        <label>説明文： <textarea name="explanation" rows="4" cols="40" class="entry_explanation"></textarea></label><br>
        <label>HP／SNS：<input type="text" name="website_url" class="entry_form"></label><br>
        <label>画像：<input type="file" name="upfile" accept="image/*" capture="camera" class="entry_form"></label><br>
        <input type="submit" value="登録する" class="register">
    </div>

  </fieldset>

</form>


<!-- Main[End] -->


<!-- jqueryが先 -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<!-- script.jsを読み込む -->
<script src='js/script.js'></script>


</body>
</html>
